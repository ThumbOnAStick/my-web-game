/**
 * @enum {string}
 */
export const ControllerStatus = {
    OFF: 'off',
    RUNNING: 'running'
};


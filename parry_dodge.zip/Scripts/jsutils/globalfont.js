export const GlobalFonts = {
    small: "15px Arial",
    normal: "20px Arial",
    medium: "30px Arial",
    large: "60px Arial",
    debug: "18px Arial"
};
